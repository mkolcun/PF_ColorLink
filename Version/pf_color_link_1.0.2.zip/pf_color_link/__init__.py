# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "PF: Color Link",
    "author" : "MaK", 
    "description" : "Share color palettes between DCC",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 2),
    "location" : "",
    "waring" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import bpy, math, re


addon_keymaps = {}
_icons = None
nodetree = {'sna_ismax': False, 'sna_iscolorloaded': False, 'sna_clrslengthint_max': 0, 'sna_clrnames_max': [], 'sna_clrcodesrgb_max': [], 'sna_clrcodesrgb_raw_max': [], 'sna_clrcodesrgba_max': [], 'sna_clrcodesrgba_raw_max': [], 'sna_clrslengthint_unity': 0, 'sna_clrnames_unity': [], 'sna_clrcodesrgb_unity': [], 'sna_clrcodesrgb_raw_unity': [], 'sna_clrcodesrgba_unity': [], 'sna_clrcodesrgba_raw_unity': [], }
class SNA_OT_Clrset_Eb765(bpy.types.Operator):
    bl_idname = "sna.clrset_eb765"
    bl_label = "clrSet"
    bl_description = "Apply Color on masked selection"
    bl_options = {"REGISTER", "UNDO"}
    sna_button_id: bpy.props.IntProperty(name='Button Id', description='', default=0, subtype='NONE')

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        if nodetree['sna_ismax']:
            bpy.context.scene.tool_settings.unified_paint_settings.color = bpy.context.scene.sna_palettemax[self.sna_button_id].colorrgb_raw_max
        else:
            bpy.context.scene.tool_settings.unified_paint_settings.color = bpy.context.scene.sna_paletteunity[self.sna_button_id].colorrgb_raw_unity
        bpy.ops.paint.vertex_color_set()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_clr_load_EA318(layout_function, ):
    pass
    row_2F764 = layout_function.row(heading='', align=False)
    row_2F764.alert = False
    row_2F764.enabled = True
    row_2F764.active = True
    row_2F764.use_property_split = False
    row_2F764.use_property_decorate = False
    row_2F764.scale_x = 1.0
    row_2F764.scale_y = 1.0
    row_2F764.alignment = 'Expand'.upper()
    box_CDBCD = row_2F764.box()
    box_CDBCD.alert = False
    box_CDBCD.enabled = True
    box_CDBCD.active = True
    box_CDBCD.use_property_split = False
    box_CDBCD.use_property_decorate = False
    box_CDBCD.alignment = 'Expand'.upper()
    box_CDBCD.scale_x = 1.0
    box_CDBCD.scale_y = 1.0
    col_883E1 = box_CDBCD.column(heading='', align=False)
    col_883E1.alert = False
    col_883E1.enabled = True
    col_883E1.active = True
    col_883E1.use_property_split = False
    col_883E1.use_property_decorate = False
    col_883E1.scale_x = 1.0
    col_883E1.scale_y = 1.0
    col_883E1.alignment = 'Expand'.upper()
    col_883E1.label(text='Max Colors', icon_value=0)
    box_30DFB = col_883E1.box()
    box_30DFB.alert = False
    box_30DFB.enabled = True
    box_30DFB.active = True
    box_30DFB.use_property_split = False
    box_30DFB.use_property_decorate = False
    box_30DFB.alignment = 'Expand'.upper()
    box_30DFB.scale_x = 1.0
    box_30DFB.scale_y = 1.0
    row_A124D = box_30DFB.row(heading='', align=False)
    row_A124D.alert = False
    row_A124D.enabled = True
    row_A124D.active = True
    row_A124D.use_property_split = False
    row_A124D.use_property_decorate = False
    row_A124D.scale_x = 1.0
    row_A124D.scale_y = 1.0
    row_A124D.alignment = 'Expand'.upper()
    row_A124D.prop(bpy.context.scene, 'sna_colorlibpathmax', text='', icon_value=0, emboss=True)
    op = row_A124D.operator('sna.load_max_colors_7bd98', text='', icon_value=706, emboss=True, depress=False)
    box_AAC0B = row_2F764.box()
    box_AAC0B.alert = False
    box_AAC0B.enabled = True
    box_AAC0B.active = True
    box_AAC0B.use_property_split = False
    box_AAC0B.use_property_decorate = False
    box_AAC0B.alignment = 'Expand'.upper()
    box_AAC0B.scale_x = 1.0
    box_AAC0B.scale_y = 1.0
    col_129E3 = box_AAC0B.column(heading='', align=False)
    col_129E3.alert = False
    col_129E3.enabled = True
    col_129E3.active = True
    col_129E3.use_property_split = False
    col_129E3.use_property_decorate = False
    col_129E3.scale_x = 1.0
    col_129E3.scale_y = 1.0
    col_129E3.alignment = 'Expand'.upper()
    col_129E3.label(text='Unity Colors', icon_value=0)
    box_7E47A = col_129E3.box()
    box_7E47A.alert = False
    box_7E47A.enabled = True
    box_7E47A.active = True
    box_7E47A.use_property_split = False
    box_7E47A.use_property_decorate = False
    box_7E47A.alignment = 'Expand'.upper()
    box_7E47A.scale_x = 1.0
    box_7E47A.scale_y = 1.0
    row_2899D = box_7E47A.row(heading='', align=False)
    row_2899D.alert = False
    row_2899D.enabled = True
    row_2899D.active = True
    row_2899D.use_property_split = False
    row_2899D.use_property_decorate = False
    row_2899D.scale_x = 1.0
    row_2899D.scale_y = 1.0
    row_2899D.alignment = 'Expand'.upper()
    row_2899D.prop(bpy.context.scene, 'sna_colorlibpathunity', text='', icon_value=0, emboss=True)
    op = row_2899D.operator('sna.load_unity_colors_3e2cc', text='', icon_value=706, emboss=True, depress=False)


class SNA_OT_Load_Unity_Colors_3E2Cc(bpy.types.Operator):
    bl_idname = "sna.load_unity_colors_3e2cc"
    bl_label = "Load Unity Colors"
    bl_description = "Load palette from CI Project"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        clrsLib = bpy.path.abspath(bpy.context.scene.sna_colorlibpathunity)
        clrsLengthInt_unity = None
        clrCodesRGBA_unity = None
        clrNames_unity = None
        clrCodesRGB_unity = None
        clrCodesRGBA_raw_unity = None
        clrCodesRGB_raw_unity = None
        #   ---unity---
        ######################
        #BLENDER COLOR CONVERSION

        def to_blender_color(c):
            c = min(max(0, c), 255) / 255
            return c / 12.92 if c < 0.04045 else math.pow((c + 0.055) / 1.055, 2.4)

        def from_blender_color(c):
            color = max(0.0, c * 12.92) if c < 0.0031308 else 1.055 * math.pow(c, 1.0 / 2.4) - 0.055
            return hex(max(min(int(color * 255 + 0.5), 255), 0))
        ######################
        #LOAD COLOR LIB
        with open(clrsLib, 'r', encoding="us-ascii") as file:
            clrs_unity = file.read()
            file.close()
        ######################
        #PARSE DATA FROM FILES
        colorsFound = re.findall(r'(m_Color: {r: (.+), g: (.+), b: (.+), a: (.+)})', clrs_unity)
        #LISTS OF COLORS TO WORK WITH IN 'VISUAL SCRIPTING EDITOR'
        clrCodesRGB_unity = []
        clrCodesRGB_raw_unity = []
        clrCodesRGBA_unity = []
        clrCodesRGBA_raw_unity = []
        #CONSTANT TO GET RGB[256, 256, 256, 256]
        k = 255 
        for list in colorsFound:
            data = (list[1], list[2], list[3], list[4])
            r_raw = float(data[0])
            g_raw = float(data[1])
            b_raw = float(data[2])
            a_raw = float(data[3])
            r = float(data[0])*k
            g = float(data[1])*k
            b = float(data[2])*k
            a = float(data[3])*k
            r = to_blender_color(r)
            g = to_blender_color(g)
            b = to_blender_color(b)
            a = to_blender_color(a)
            clrCodesRGB_unity.append ([r,g,b])
            clrCodesRGB_raw_unity.append ([r_raw, g_raw, b_raw])
            clrCodesRGBA_unity.append ([r,g,b,a])
            clrCodesRGBA_raw_unity.append ([r_raw,g_raw,b_raw,a_raw])
        namesFound = re.findall(r'(- m_Name: (.+))', clrs_unity)
        #LISTS OF COLORS TO WORK WITH IN 'VISUAL SCRIPTING EDITOR'
        clrNames_unity = []
        for list in namesFound:
            data = list
            clrNames_unity.append (data[1])
        clrsLengthInt_unity = len(clrNames_unity)
        clrsLengthStr_unity = str(clrsLengthInt_unity)
        print(clrNames_unity)
        #print(clrsLengthInt_unity)
        #print(clrCodesRGB_unity)
        #print(clrCodesRGB_raw_unity)
        #print(clrCodesRGBA_unity)
        #print(clrCodesRGBA_raw_unity)
        print("Unity Colors loaded successfully.")
        nodetree['sna_ismax'] = False
        nodetree['sna_iscolorloaded'] = True
        bpy.context.scene.sna_paletteunity.clear()
        nodetree['sna_clrslengthint_unity'] = clrsLengthInt_unity
        nodetree['sna_clrnames_unity'] = clrNames_unity
        nodetree['sna_clrcodesrgb_unity'] = clrCodesRGB_unity
        nodetree['sna_clrcodesrgb_raw_unity'] = clrCodesRGB_raw_unity
        nodetree['sna_clrcodesrgba_unity'] = clrCodesRGBA_unity
        nodetree['sna_clrcodesrgba_raw_unity'] = clrCodesRGBA_raw_unity
        for i_6E525 in range(clrsLengthInt_unity):
            item_A14D1 = bpy.context.scene.sna_paletteunity.add()
            item_A14D1.name_unity = nodetree['sna_clrnames_unity'][i_6E525]
            item_A14D1.colorrgb_unity = nodetree['sna_clrcodesrgb_unity'][i_6E525]
            item_A14D1.colorrgb_raw_unity = nodetree['sna_clrcodesrgb_raw_unity'][i_6E525]
            item_A14D1.colorrgba_unity = nodetree['sna_clrcodesrgba_unity'][i_6E525]
            item_A14D1.colorrgba_raw_unity = nodetree['sna_clrcodesrgba_raw_unity'][i_6E525]
        print(str(clrNames_unity), '')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Load_Max_Colors_7Bd98(bpy.types.Operator):
    bl_idname = "sna.load_max_colors_7bd98"
    bl_label = "Load Max Colors"
    bl_description = "Load palette from CI Project"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        clrsLib = bpy.path.abspath(bpy.context.scene.sna_colorlibpathmax)
        clrsLengthInt_max = None
        clrCodesRGBA_max = None
        clrNames_max = None
        clrCodesRGB_max = None
        clrCodesRGBA_raw_max = None
        clrCodesRGB_raw_max = None
        #   ---3ds max---
        ######################
        #BLENDER COLOR CONVERSION

        def to_blender_color(c):
            c = min(max(0, c), 255) / 255
            return c / 12.92 if c < 0.04045 else math.pow((c + 0.055) / 1.055, 2.4)

        def from_blender_color(c):
            color = max(0.0, c * 12.92) if c < 0.0031308 else 1.055 * math.pow(c, 1.0 / 2.4) - 0.055
            return hex(max(min(int(color * 255 + 0.5), 255), 0))
        ######################
        #LOAD COLOR LIB
        with open(clrsLib, 'r', encoding="utf16") as file:
            clrs_max = file.readlines()
            file.close()
        ######################
        #PARSE DATA FROM FILES
        del clrs_max[:25]
        for clr in clrs_max:
            data = clr.split("\n")
            #LISTS OF COLORS TO WORK WITH IN 'VISUAL SCRIPTING EDITOR'
            clrNames_max = []
            clrCodesRGB_max = []
            clrCodesRGB_raw_max = []
            clrCodesRGBA_max = []
            clrCodesRGBA_raw_max = []
            #CONSTANT TO GET RGB[256, 256, 256, 256]
            k = 255
            clrsLengthInt_max = len(clrs_max)
            clrsLengthStr_max = str(clrsLengthInt_max)
        #WRITE PARSED DATA
        for line in clrs_max:
            data = line.strip().split(" ")
            n = data[4]
            clrNames_max.append (n)
            r_raw = float(data[0])
            g_raw = float(data[1])
            b_raw = float(data[2])
            a_raw = float(data[3])
            r = float(data[0])*k
            g = float(data[1])*k
            b = float(data[2])*k
            a = float(data[3])*k
            r = to_blender_color(r)
            g = to_blender_color(g)
            b = to_blender_color(b)
            a = to_blender_color(a)
            clrCodesRGB_max.append ([r,g,b])
            clrCodesRGB_raw_max.append ([r_raw, g_raw, b_raw])
            clrCodesRGBA_max.append ([r,g,b,a])
            clrCodesRGBA_raw_max.append ([r_raw,g_raw,b_raw,a_raw])
        #print(clrNames_max)
        #print(clrsLengthInt_max)
        #print(clrCodesRGB_max)
        #print(clrCodesRGB_raw_max)
        #print(clrCodesRGBA_max)
        #print(clrCodesRGBA_raw_max)
        print("Max Colors loaded successfully.")
        nodetree['sna_ismax'] = True
        nodetree['sna_iscolorloaded'] = True
        bpy.context.scene.sna_palettemax.clear()
        nodetree['sna_clrslengthint_max'] = clrsLengthInt_max
        nodetree['sna_clrcodesrgba_max'] = clrCodesRGBA_max
        nodetree['sna_clrnames_max'] = clrNames_max
        nodetree['sna_clrcodesrgb_max'] = clrCodesRGB_max
        nodetree['sna_clrcodesrgb_raw_max'] = clrCodesRGB_raw_max
        nodetree['sna_clrcodesrgba_raw_max'] = clrCodesRGBA_raw_max
        for i_EE43B in range(clrsLengthInt_max):
            item_F9547 = bpy.context.scene.sna_palettemax.add()
            item_F9547.name_max = nodetree['sna_clrnames_max'][i_EE43B]
            item_F9547.colorrgba_max = nodetree['sna_clrcodesrgba_max'][i_EE43B]
            item_F9547.colorrgba_raw_max = nodetree['sna_clrcodesrgba_raw_max'][i_EE43B]
            item_F9547.colorrgb_max = nodetree['sna_clrcodesrgb_max'][i_EE43B]
            item_F9547.colorrgb_raw_max = nodetree['sna_clrcodesrgb_raw_max'][i_EE43B]
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_clr_button_C75E8(layout_function, ):
    pass
    if nodetree['sna_iscolorloaded']:
        col_E6A2E = layout_function.column(heading='', align=True)
        col_E6A2E.alert = False
        col_E6A2E.enabled = 'PAINT_VERTEX'==bpy.context.mode
        col_E6A2E.active = True
        col_E6A2E.use_property_split = False
        col_E6A2E.use_property_decorate = False
        col_E6A2E.scale_x = 1.0
        col_E6A2E.scale_y = 1.0
        col_E6A2E.alignment = 'Center'.upper()
        col_E6A2E.separator(factor=2.0)
        if 'PAINT_VERTEX'==bpy.context.mode:
            box_6A3BD = col_E6A2E.box()
            box_6A3BD.alert = False
            box_6A3BD.enabled = True
            box_6A3BD.active = True
            box_6A3BD.use_property_split = False
            box_6A3BD.use_property_decorate = False
            box_6A3BD.alignment = 'Expand'.upper()
            box_6A3BD.scale_x = 1.0
            box_6A3BD.scale_y = 1.0
            row_4DD00 = box_6A3BD.row(heading='', align=True)
            row_4DD00.alert = False
            row_4DD00.enabled = True
            row_4DD00.active = False
            row_4DD00.use_property_split = False
            row_4DD00.use_property_decorate = False
            row_4DD00.scale_x = 1.0
            row_4DD00.scale_y = 1.0
            row_4DD00.alignment = 'Expand'.upper()
            row_4DD00.label(text='Name', icon_value=5)
            row_4DD00.label(text='Color', icon_value=5)
        else:
            box_C9288 = col_E6A2E.box()
            box_C9288.alert = False
            box_C9288.enabled = True
            box_C9288.active = True
            box_C9288.use_property_split = False
            box_C9288.use_property_decorate = False
            box_C9288.alignment = 'Expand'.upper()
            box_C9288.scale_x = 1.0
            box_C9288.scale_y = 1.0
            box_C9288.label(text="Set 'Vertex Paint' mode to activate buttons", icon_value=0)
        col_E6A2E.separator(factor=2.0)
        if nodetree['sna_ismax']:
            for i_336AA in range(nodetree['sna_clrslengthint_max']):
                row_6ADC0 = col_E6A2E.row(heading='', align=True)
                row_6ADC0.alert = False
                row_6ADC0.enabled = True
                row_6ADC0.active = True
                row_6ADC0.use_property_split = False
                row_6ADC0.use_property_decorate = False
                row_6ADC0.scale_x = 1.0
                row_6ADC0.scale_y = 0.75
                row_6ADC0.alignment = 'Expand'.upper()
                op = row_6ADC0.operator('sna.clrset_eb765', text=bpy.context.scene.sna_palettemax[i_336AA].name_max, icon_value=0, emboss=True, depress=False)
                op.sna_button_id = i_336AA
                row_6ADC0.prop(bpy.context.scene.sna_palettemax[i_336AA], 'colorrgba_max', text='', icon_value=0, emboss=True)
        else:
            for i_A959F in range(nodetree['sna_clrslengthint_unity']):
                row_0D159 = col_E6A2E.row(heading='', align=True)
                row_0D159.alert = False
                row_0D159.enabled = True
                row_0D159.active = True
                row_0D159.use_property_split = False
                row_0D159.use_property_decorate = False
                row_0D159.scale_x = 1.0
                row_0D159.scale_y = 0.75
                row_0D159.alignment = 'Expand'.upper()
                op = row_0D159.operator('sna.clrset_eb765', text=bpy.context.scene.sna_paletteunity[i_A959F].name_unity, icon_value=0, emboss=True, depress=False)
                op.sna_button_id = i_A959F
                row_0D159.prop(bpy.context.scene.sna_paletteunity[i_A959F], 'colorrgba_unity', text='', icon_value=0, emboss=True)


def sna_add_to_view3d_pt_tools_active_C02E6(self, context):
    if not (False):
        layout = self.layout
        layout.label(text='PF: Color Link', icon_value=0)
        box_A3BD0 = layout.box()
        box_A3BD0.alert = False
        box_A3BD0.enabled = True
        box_A3BD0.active = True
        box_A3BD0.use_property_split = False
        box_A3BD0.use_property_decorate = False
        box_A3BD0.alignment = 'Expand'.upper()
        box_A3BD0.scale_x = 1.0
        box_A3BD0.scale_y = 1.0
        box_A3BD0.label(text='Choose Color Palette', icon_value=0)
        col_32768 = box_A3BD0.column(heading='', align=True)
        col_32768.alert = False
        col_32768.enabled = True
        col_32768.active = True
        col_32768.use_property_split = False
        col_32768.use_property_decorate = False
        col_32768.scale_x = 1.0
        col_32768.scale_y = 1.0
        col_32768.alignment = 'Expand'.upper()
        layout_function = col_32768
        sna_clr_load_EA318(layout_function, )
        layout_function = col_32768
        sna_clr_button_C75E8(layout_function, )


class SNA_GROUP_sna_groupmax(bpy.types.PropertyGroup):
    name_max: bpy.props.StringProperty(name='Name_Max', description='', default='', subtype='NONE', maxlen=0)
    colorrgb_max: bpy.props.FloatVectorProperty(name='ColorRGB_Max', description='', size=3, default=(0.0, 0.0, 0.0), subtype='COLOR', unit='NONE', min=0.0, soft_min=0.0, max=1.0, soft_max=1.0, step=10, precision=6)
    colorrgb_raw_max: bpy.props.FloatVectorProperty(name='ColorRGB_Raw_Max', description='', size=3, default=(0.0, 0.0, 0.0), subtype='COLOR', unit='NONE', min=0.0, max=1.0, step=3, precision=6)
    colorrgba_max: bpy.props.FloatVectorProperty(name='ColorRGBA_Max', description='RGBA Value', size=4, default=(0.0, 0.0, 0.0, 0.0), subtype='COLOR', unit='NONE', min=0.0, soft_min=0.0, max=1.0, soft_max=1.0, step=10, precision=6)
    colorrgba_raw_max: bpy.props.FloatVectorProperty(name='ColorRGBA_Raw_Max', description='', size=4, default=(0.0, 0.0, 0.0, 0.0), subtype='COLOR', unit='NONE', min=0.0, step=3, precision=6)


class SNA_GROUP_sna_groupunity(bpy.types.PropertyGroup):
    name_unity: bpy.props.StringProperty(name='Name_Unity', description='', default='', subtype='NONE', maxlen=0)
    colorrgb_unity: bpy.props.FloatVectorProperty(name='ColorRGB_Unity', description='', size=3, default=(0.0, 0.0, 0.0), subtype='COLOR', unit='NONE', min=0.0, soft_min=0.0, max=1.0, soft_max=1.0, step=3, precision=6)
    colorrgb_raw_unity: bpy.props.FloatVectorProperty(name='ColorRGB_Raw_Unity', description='', size=3, default=(0.0, 0.0, 0.0), subtype='COLOR', unit='NONE', min=0.0, soft_min=0.0, max=1.0, soft_max=1.0, step=3, precision=6)
    colorrgba_unity: bpy.props.FloatVectorProperty(name='ColorRGBA_Unity', description='', size=4, default=(0.0, 0.0, 0.0, 0.0), subtype='COLOR', unit='NONE', min=0.0, soft_min=0.0, max=1.0, soft_max=1.0, step=3, precision=6)
    colorrgba_raw_unity: bpy.props.FloatVectorProperty(name='ColorRGBA_Raw_Unity', description='', size=4, default=(0.0, 0.0, 0.0, 0.0), subtype='COLOR', unit='NONE', min=0.0, soft_min=0.0, max=1.0, soft_max=1.0, step=3, precision=6)


class SNA_GROUP_sna_groupshortcut(bpy.types.PropertyGroup):
    maskvertex: bpy.props.BoolProperty(name='MaskVertex', description='', default=False)
    maskface: bpy.props.BoolProperty(name='MaskFace', description='', default=False)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_GROUP_sna_groupmax)
    bpy.utils.register_class(SNA_GROUP_sna_groupunity)
    bpy.utils.register_class(SNA_GROUP_sna_groupshortcut)
    bpy.types.Scene.sna_palettemax = bpy.props.CollectionProperty(name='PaletteMax', description='', type=SNA_GROUP_sna_groupmax)
    bpy.types.Scene.sna_colorlibpathmax = bpy.props.StringProperty(name='ColorLibPathMax', description='', default='', subtype='FILE_PATH', maxlen=0)
    bpy.types.Scene.sna_paletteunity = bpy.props.CollectionProperty(name='PaletteUnity', description='', type=SNA_GROUP_sna_groupunity)
    bpy.types.Scene.sna_colorlibpathunity = bpy.props.StringProperty(name='ColorLibPathUnity', description='', default='', subtype='FILE_PATH', maxlen=0)
    bpy.types.Scene.sna_shortcuts = bpy.props.StringProperty(name='Shortcuts', description='', default='', subtype='NONE', maxlen=0)
    bpy.utils.register_class(SNA_OT_Clrset_Eb765)
    bpy.utils.register_class(SNA_OT_Load_Unity_Colors_3E2Cc)
    bpy.utils.register_class(SNA_OT_Load_Max_Colors_7Bd98)
    bpy.types.VIEW3D_PT_tools_active.append(sna_add_to_view3d_pt_tools_active_C02E6)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_shortcuts
    del bpy.types.Scene.sna_colorlibpathunity
    del bpy.types.Scene.sna_paletteunity
    del bpy.types.Scene.sna_colorlibpathmax
    del bpy.types.Scene.sna_palettemax
    bpy.utils.unregister_class(SNA_GROUP_sna_groupshortcut)
    bpy.utils.unregister_class(SNA_GROUP_sna_groupunity)
    bpy.utils.unregister_class(SNA_GROUP_sna_groupmax)
    bpy.utils.unregister_class(SNA_OT_Clrset_Eb765)
    bpy.utils.unregister_class(SNA_OT_Load_Unity_Colors_3E2Cc)
    bpy.utils.unregister_class(SNA_OT_Load_Max_Colors_7Bd98)
    bpy.types.VIEW3D_PT_tools_active.remove(sna_add_to_view3d_pt_tools_active_C02E6)
